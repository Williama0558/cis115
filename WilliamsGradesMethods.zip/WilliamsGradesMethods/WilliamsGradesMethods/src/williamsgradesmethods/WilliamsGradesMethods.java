/**
 *Aaron Williams
 *11/29/2017
 *Grading Program (With Methods)
 *Will allow the user to enter in multiple grades and then give the user a
 *letter grade based on their average grade.
 **/
package williamsgradesmethods;
import java.util.Scanner;
public class WilliamsGradesMethods 
{
    public static void main(String[] args)
    {
        Scanner k = new Scanner(System.in);
        do
        {
            displayInfo();
            double numberOfGrades = 0;
            numberOfGrades = getInput();
            double gradeAverage = 0;
            gradeAverage = getAverage(numberOfGrades);
            char gradeLetter;
            gradeLetter = determineLetterGrade(gradeAverage);
            displayGrades(gradeAverage, gradeLetter); 
            System.out.print("Type 'Y' to run the program again: ");


        }
        while(k.next().equalsIgnoreCase("Y"));
        System.out.println("See you next time!");
    }

    
    public static void displayInfo()
    {
        System.out.println("Welcome to the Grading Program!");
        System.out.println("Created by: Aaron Williams");
    }
    
    
    public static double getInput()
    {
        Scanner k = new Scanner(System.in);
        System.out.print("How many grade would you like to enter? ");
        double numberOfGrades = k.nextDouble();
        return numberOfGrades;
    }
    
    
    public static double getAverage(double numberOfGrades)
    {
        Scanner k = new Scanner(System.in);
        double gradeTotal = 0;
        for (int gradesGraded = 1; gradesGraded <= numberOfGrades; gradesGraded++)
        {
            System.out.print("Please enter in a grade: ");
            double userGrade = k.nextDouble();
            gradeTotal += userGrade;
        }
       double gradeAverage = gradeTotal / numberOfGrades;
       return gradeAverage;
    }
    
    
    public static char determineLetterGrade(double gradeAverage)
    {
        double gradeA = 89.5;
        double gradeB = 79.5;
        double gradeC = 69.5;
        double gradeD = 59.5;
        char gradeLetter;
                
        if (gradeAverage >= gradeA)
        {
            gradeLetter = 'A';
        }
        else if (gradeAverage >= gradeB)
        {
            gradeLetter = 'B';
        }
        else if (gradeAverage >= gradeC)
        {
            gradeLetter = 'C';
        }
        else if (gradeAverage >= gradeD)
        {
            gradeLetter = 'D';
        }
        else
        {
            gradeLetter = 'F';
        }
        return gradeLetter;
    }
    
    
    public static void displayGrades(double gradeAverage,char gradeLetter)
    {
        double gradeA = 89.5;
        double gradeD = 59.5;
        if (gradeAverage >= gradeA || gradeAverage < gradeD)
        {
          System.out.print("Your average was: " + gradeAverage + "\n"
                            + "Your letter grade was an: " + gradeLetter + "\n");
        }
        else
        {
            System.out.print("Your average was: " + gradeAverage + "\n"
                            + "Your letter grade was a: " + gradeLetter + "\n");
        }
                
    }

}
