/**
 *Aaron Williams
 *11/29/2017
 *Grading Program (Without Using Methods)
 *Will allow the user to enter in multiple grades and then give the user a
 *letter grade based on their average grade.
 **/
package williamsgradeswomethods;
import java.util.Scanner;
public class WilliamsGradesWOMethods 
{
    
    public static void main(String[] args)
    {
        double gradeA = 89.5;
        double gradeB = 79.5;
        double gradeC = 69.5;
        double gradeD = 59.5;
        char gradeLetter;
        double gradeTotal = 0;
                
        Scanner k = new Scanner(System.in);
        System.out.println("Welcome to the Grading Program!\n");
        System.out.print("How many grade would you like to enter? ");
        double numberOfGrades = k.nextDouble();
        
        for (int gradesGraded = 1; gradesGraded <= numberOfGrades; gradesGraded++)
        {
            System.out.print("Please enter in a grade: ");
            double userGrade = k.nextDouble();
            gradeTotal += userGrade;
        }
        double gradeAverage = gradeTotal / numberOfGrades;
        
        if (gradeAverage >= gradeA)
        {
            gradeLetter = 'A';
        }
        else if (gradeAverage >= gradeB)
        {
            gradeLetter = 'B';
        }
        else if (gradeAverage >= gradeC)
        {
            gradeLetter = 'C';
        }
        else if (gradeAverage >= gradeD)
        {
            gradeLetter = 'D';
        }
        else
        {
            gradeLetter = 'F';
        }
        //else
        //{
         //   System.out.print(gradeAverag + "is not a valid grade. Your grade must be between 0-100.");
        //}
        if (gradeAverage >= gradeA || gradeAverage < gradeD)
        {
          System.out.print("Your average was: " + gradeAverage + "\n"
                            + "Your letter grade was an: " + gradeLetter + "\n");
        }
        else
        {
            System.out.print("Your average was: " + gradeAverage + "\n"
                            + "Your letter grade was a: " + gradeLetter + "\n");
        }
    }

}
