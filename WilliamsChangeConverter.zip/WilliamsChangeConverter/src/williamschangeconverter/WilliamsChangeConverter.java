/**
 *Aaron Williams
 *11/20/2017
 *Change Converter
 *Will show the amount of each coin in the user's inputted change.
 **/
package williamschangeconverter;
import java.util.Scanner;
public class WilliamsChangeConverter 
{
    
    public static void main(String[] args) 
    {
        System.out.print("Welcome to the Change Converter!\n");
        
        Scanner keyboard = new Scanner(System.in);
        //Asks the user for their amount in change
        System.out.print("Please enter how much change you have: ");
        //Holds the amount the user entered
        int amount = keyboard.nextInt();
        //Variables and constants needed for the program
        int pennies = 0;
        int nickels = 0;
        int dimes = 0;
        int quarters = 0;
        int QUARTER = 25;
        int DIME = 10;
        int NICKEL = 5;
        
        //Shows the user an error if they enter a number less than 1
        if (amount < 1) 
        {
            System.out.println("Error: Cannot enter a value less than 1!");
        } 
        else 
        {
            //Runs the loop until all quarters are subtracted from amount, then moves to the next loop
            while (amount >= QUARTER) 
            {
                //Subtracts a quarter each time the loop runs
                amount -= QUARTER;
                //Adds one increment to the 'quarter' variable
                quarters++;
            }
            //Runs the loop until all dimes are subtracted from amount, then moves to the next loop
            while (amount >= DIME) 
            {
                //Subtracts a dime each time the loop runs
                amount -= DIME;
                //Adds one increment to the 'dime' variable
                dimes++;
            }
            //Runs the loop until all nickels are subtracted from amount, then moves to the next loop
            while (amount >= NICKEL) 
            {
                //Subtracts a nickel each time the loop runs
                amount -= NICKEL;
                //Adds one increment to the 'nickel variable
                nickels++;
            }
            //Any remaining amount is stored in the 'pennies' variable
            pennies = amount;
            
            //Displays the results
            System.out.print("Your change is: " + quarters + " Quarters\n\t\t"
                            + dimes + " Dimes\n\t\t" 
                            + nickels + " Nickels \n\t\t"
                            + pennies + " Pennies\n");
        }
    }
}